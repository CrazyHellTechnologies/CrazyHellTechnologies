**N3RDP0RT4L Website Repository**

**TODO:**
- [✓] Work on slight formating. 
- [✓] Text correction. 
- [✓] Apple fonts.
- [✓] Adding enuma device specs.
- [✓] Adding Discord HTML embeds, and icon.
- [✓] Fix-up some code.

**Our Fosscord Instance:**
http://n3rdp0rt4l.duckdns.org:9999/app

**NOTICE:**
Please read the rules to comply with the rules. You adhere to the N3RDP0RT4L terms of service, and the current rules upon using the N3RDP0RT4L services.

__**Signed Off by Austin Walker BSD 3 License...**__
